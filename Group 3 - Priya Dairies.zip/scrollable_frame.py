import tkinter as tk
import platform

class ScrollFrame(tk.Frame):
    def __init__(self, parent):
        super().__init__(parent)  # Create a frame (self)
        
        self.canvas = tk.Canvas(self, borderwidth=0, background="#36454F")  # Canvas on self
        self.viewPort = tk.Frame(self.canvas, background="#36454F")  # Frame to hold child widgets
        self.vsb = tk.Scrollbar(self, orient="vertical", command=self.canvas.yview)  # Scrollbar on self
        self.canvas.configure(yscrollcommand=self.vsb.set)  # Attach scrollbar to canvas scroll
        
        self.vsb.pack(side="right", fill="y")  # Pack scrollbar to right of self
        self.canvas.pack(side="left", fill="both", expand=True)  # Pack canvas to left of self
        self.canvas_window = self.canvas.create_window(
            (4, 4), window=self.viewPort, anchor="nw", tags="self.viewPort"
        )
        
        self.viewPort.bind("<Configure>", self.onFrameConfigure)  # Bind resizing events
        self.canvas.bind("<Configure>", self.onCanvasConfigure)
        
        self.viewPort.bind('<Enter>', self.onEnter)  # Bind mouse events
        self.viewPort.bind('<Leave>', self.onLeave)
        
        self.onFrameConfigure(None)  # Initial resize adjustment

    def onFrameConfigure(self, event):
        """Reset the scroll region to encompass the inner frame."""
        self.canvas.configure(scrollregion=self.canvas.bbox("all"))

    def onCanvasConfigure(self, event):
        """Reset the canvas window width."""
        self.canvas.itemconfig(self.canvas_window, width=event.width)

    def onMouseWheel(self, event):
        """Cross-platform scroll wheel support."""
        if platform.system() == 'Windows':
            self.canvas.yview_scroll(int(-1 * (event.delta / 120)), "units")
        elif platform.system() == 'Darwin':
            self.canvas.yview_scroll(int(-1 * event.delta), "units")
        else:
            if event.num == 4:
                self.canvas.yview_scroll(-1, "units")
            elif event.num == 5:
                self.canvas.yview_scroll(1, "units")

    def onEnter(self, event):
        """Bind mouse wheel when the cursor enters."""
        if platform.system() == 'Linux':
            self.canvas.bind_all("<Button-4>", self.onMouseWheel)
            self.canvas.bind_all("<Button-5>", self.onMouseWheel)
        else:
            self.canvas.bind_all("<MouseWheel>", self.onMouseWheel)

    def onLeave(self, event):
        """Unbind mouse wheel when the cursor leaves."""
        if platform.system() == 'Linux':
            self.canvas.unbind_all("<Button-4>")
            self.canvas.unbind_all("<Button-5>")
        else:
            self.canvas.unbind_all("<MouseWheel>")
