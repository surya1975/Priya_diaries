import customtkinter
def display_customer_orders(self, customer_id, back_callback):
    """Display all orders placed by the logged-in customer."""
    self.clear_frame()  # Clear the current content
    self.add_back_button(lambda: back_callback(self))  # Add back button

    # Fetch orders for the customer
    try:
        results = self.fetch_all_query(
            """
            SELECT 
                order_number,
                Store.name AS store_name,
                delivery_status,
                date,
                order_time
            FROM 
                Customer_Order
            JOIN 
                Store ON Customer_Order.store_id = Store.store_id
            WHERE 
                customer_id = %s
            ORDER BY 
                date DESC, order_time DESC
            """,
            (customer_id,)  # Pass the logged-in customer's ID
        )
    except Exception as e:
        print(f"Database error: {e}")
        customtkinter.CTkLabel(
            self.scroll_frame.viewPort,
            text="An error occurred while retrieving your orders.",
            font=("Helvetica", 14),
            text_color="red"
        ).pack(pady=10)
        return

    # Add a title for the orders
    customtkinter.CTkLabel(
        self.scroll_frame.viewPort,
        text="Your Orders",
        font=("Helvetica", 18),
        text_color="white"
    ).pack(pady=10)

    # If no orders are found
    if not results:
        customtkinter.CTkLabel(
            self.scroll_frame.viewPort,
            text="You have not placed any orders yet.",
            font=("Helvetica", 14),
            text_color="gray"
        ).pack(pady=20)
        return

    # Define column widths for consistent alignment
    column_widths = [10, 10, 10, 10, 10]  # Adjust widths as needed

    # Add headers to the top of the scrollable frame
    header_frame = customtkinter.CTkFrame(self.scroll_frame.viewPort)
    header_frame.pack(pady=5, padx=10, fill="x")

    # Define header labels
    headers = ["Order Number", "Store Name", "Delivery Status", "Order Date", "Order Time"]
    for col, header in enumerate(headers):
        customtkinter.CTkLabel(
            header_frame,
            text=header,
            font=("Arial", 14, "bold"),
            anchor="w",
            width=column_widths[col] * 10
        ).grid(row=0, column=col, padx=5, pady=5, sticky="w")

    # Display each order
    for row, order in enumerate(results, start=1):
        row_frame = customtkinter.CTkFrame(self.scroll_frame.viewPort)
        row_frame.pack(pady=2, padx=10, fill="x")

        # Order details for each row
        order_data = [
            order[0],  # Order number
            order[1],  # Store name
            order[2],  # Delivery status
            order[3].strftime("%Y-%m-%d"),  # Order date
            order[4].strftime("%H:%M:%S"),  # Delivery time
        ]
        for col, value in enumerate(order_data):
            customtkinter.CTkLabel(
                row_frame,
                text=value,
                anchor="w",
                width=column_widths[col] * 10
            ).grid(row=0, column=col, padx=5, pady=2, sticky="w")
        '''
        # Add "View Details" button
        customtkinter.CTkButton(
            row_frame,
            text="View Details",
            command=lambda order_number=order[0]: self.view_order_details(order_number, back_callback),  # Callback for order details
            fg_color="#1E90FF",
            hover_color="#4682B4",
            text_color="white",
            corner_radius=8,
            width=25,
            height=30,
        ).grid(row=0, column=len(order_data), padx=5, pady=2, sticky="w")
        '''
