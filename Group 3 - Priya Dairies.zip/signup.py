from style import ENTRY_FIELD_STYLE
import customtkinter
from tkinter import messagebox
import mysql.connector
import hashlib

def open_signup_details(self, role, back_page_callback):
    """Generic signup function for Customer and Supplier."""
    self.clear_frame()
    self.add_back_button(back_page_callback)  # Use the passed callback for the back button

    # Capitalize the role for display purposes
    role_label = role.capitalize()

    label = customtkinter.CTkLabel(self.scroll_frame.viewPort, text=f"{role_label} Signup Details", font=("Helvetica", 18))
    label.pack(pady=20)

    def create_field(frame, text):
        """Create a label and entry field."""
        customtkinter.CTkLabel(frame, text=text).pack(pady=5)
        entry = customtkinter.CTkEntry(
            frame,
            placeholder_text=f"Enter {text}",
            **ENTRY_FIELD_STYLE  # Apply the global entry field style
        )
        entry.pack(pady=5)
        return entry

    # Fields to be created
    fields = {
        "Email": create_field(self.scroll_frame.viewPort, "Email:"),
        "Password": create_field(self.scroll_frame.viewPort, "Password:"),
        "First Name": create_field(self.scroll_frame.viewPort, "First Name:"),
        "Last Name": create_field(self.scroll_frame.viewPort, "Last Name:"),
        "Phone Number": create_field(self.scroll_frame.viewPort, "Phone Number:"),
        "Street": create_field(self.scroll_frame.viewPort, "Street:"),
        "City": create_field(self.scroll_frame.viewPort, "City:"),
        "State": create_field(self.scroll_frame.viewPort, "State:"),
        "Zip Code": create_field(self.scroll_frame.viewPort, "Zip Code:")
    }

    def hash_password(password):
        """Hash the password using SHA-256."""
        return hashlib.sha256(password.encode()).hexdigest()

    def register_action():
        """Handle registration action."""
        raw_password = fields["Password"].get()
        if not raw_password.strip():
            messagebox.showerror("Signup", "Password cannot be empty.")
            return

        hashed_password = hash_password(raw_password)

        # Extract field values
        field_values = (
            hashed_password,
            fields["First Name"].get(),
            fields["Last Name"].get(),
            fields["Phone Number"].get(),
            fields["Email"].get(),
            fields["Street"].get(),
            fields["City"].get(),
            fields["State"].get(),
            fields["Zip Code"].get(),
        )

        try:
            self.execute_query(
                f"""
                INSERT INTO {role} (password, first_name, last_name, phone, email, street, city, state, zip_code) 
                VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s)
                """,
                field_values
            )
            messagebox.showinfo("Signup", f"{role_label} signup successful!")
            back_page_callback()  # Navigate back after successful signup
        except mysql.connector.IntegrityError as e:
            print(f"Database error: {e}")
            messagebox.showerror("Signup", "Username already exists.")
        except Exception as e:
            print(f"Unexpected error: {e}")
            messagebox.showerror("Signup", "An error occurred during signup.")

    # Create the "Create Account" button
    self.create_styled_button(self.scroll_frame.viewPort, "Create Account", register_action).pack(pady=10)

# Specific function calls for customer and supplier signup
def open_signup_details_customer(self):
    open_signup_details(self, role="Customer", back_page_callback=self.open_customer_page)

def open_signup_details_supplier(self):
    open_signup_details(self, role="Supplier", back_page_callback=self.open_supplier_page)
