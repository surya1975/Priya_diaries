import mysql.connector
import customtkinter
from tkinter import messagebox
from scrollable_frame import ScrollFrame
from database_setup import initialize_database
from style import GENERAL_BUTTON_STYLE, BACK_BUTTON_STYLE
from signup import open_signup_details_customer, open_signup_details_supplier
from session import Session
from supplier_dash import open_supplier_dashboard
from customer_dash import open_customer_dashboard
from login_page import open_login_page

class DairyApp:
    def __init__(self, root):
        # Initialize the MySQL database
        try:
            initialize_database()
        except Exception as e:
            print(f"Error during database initialization: {e}")
            messagebox.showerror("Error", "Failed to initialize the database. Please check the logs.")
        else:
            print("Database initialized successfully.")
        
        # Define a consistent background color
        self.root = root
        self.root.title("Priya Dairies")
        self.root.geometry("650x580")

        # Create a main frame to switch content dynamically
        self.main_frame = customtkinter.CTkFrame(root, fg_color="#36454F")  # Set frame color
        self.main_frame.pack(expand=True, fill="both")

        # Create a Scrollable Frame for dynamic content
        self.scroll_frame = ScrollFrame(self.main_frame)
        self.scroll_frame.pack(side="top", fill="both", expand=True)
        
        # Initialize the session_carts if it doesn't exist
        self.session_carts = {}     
        
        # Open the home page
        self.open_home_page()


    def execute_query(self, query, params=()):
        """Executes a database query and commits the changes."""
        try:
            # Establish the MySQL connection
            conn = mysql.connector.connect(
                host="141.209.241.91",  # Replace with MySQL host
                user="fatue2024bis698g3",  # Replace with MySQL username
                password="warm",  # Replace with MySQL password
                database="fatue2024bis698g3s"  # Replace with database name
            )
            cursor = conn.cursor()
            cursor.execute(query, params)
            conn.commit()
        except mysql.connector.Error as e:
            print(f"Database error: {e}")
            raise  # Re-raise the error to handle it elsewhere if needed
        finally:
            # Ensure resources are closed
            if cursor:
                cursor.close()
            if conn:
                conn.close()

    def fetch_query(self, query, params=()):
        """Fetches data from the database."""
        try:
            # Establish the MySQL connection
            conn = mysql.connector.connect(
                host="141.209.241.91",  # Replace with MySQL host
                user="fatue2024bis698g3",  # Replace with MySQL username
                password="warm",  # Replace with MySQL password
                database="fatue2024bis698g3s"  # Replace with database name
            )
            cursor = conn.cursor()
            cursor.execute(query, params)
            result = cursor.fetchone()  # Adjust to fetchall() if you expect multiple rows
            return result
        except mysql.connector.Error as e:
            print(f"Database error: {e}")
            raise  # Re-raise the error to handle it elsewhere if needed
        finally:
            # Ensure resources are closed
            if cursor:
                cursor.close()
            if conn:
                conn.close()

    def fetch_all_query(self, query, params=()):
        """Fetches all rows of data from the database."""
        try:
            # Establish the MySQL connection
            conn = mysql.connector.connect(
                host="141.209.241.91",
                user="fatue2024bis698g3",
                password="warm",
                database="fatue2024bis698g3s"
            )
            cursor = conn.cursor()
            cursor.execute(query, params)
            result = cursor.fetchall()  # Fetch all rows
            return result
        except mysql.connector.Error as e:
            print(f"Database error: {e}")
            raise  # Re-raise the error to handle it elsewhere if needed
        finally:
            # Ensure resources are closed
            if cursor:
                cursor.close()
            if conn:
                conn.close()

    def order_execute(self, query, params=()):
        """Place an order and return the order number."""
        try:
            # Establish the MySQL connection
            conn = mysql.connector.connect(
                host="141.209.241.91",
                user="fatue2024bis698g3",
                password="warm",  
                database="fatue2024bis698g3s"  
            )
            cursor = conn.cursor()

            cursor.execute(query, params)
            conn.commit()

            # Retrieve the last inserted order_number
            cursor.execute("SELECT LAST_INSERT_ID()")
            order_number = cursor.fetchone()[0]  # Fetch the order number

            # Return the order number
            return order_number

        except mysql.connector.Error as e:
            print(f"Database error: {e}")
            raise  # Reraise the error if needed for higher-level handling
        finally:
            # Ensure resources are closed
            if cursor:
                cursor.close()
            if conn:
                conn.close()


    def clear_frame(self):
        for widget in self.scroll_frame.viewPort.winfo_children():
            widget.destroy()
         # Reset the scroll position to the top
        self.scroll_frame.canvas.yview_moveto(0) 

    def add_back_button(self, back_command):
        """Adds a Back Button to the current frame."""
        customtkinter.CTkButton(
            self.scroll_frame.viewPort,
            text="Back",
            command=back_command,
            **BACK_BUTTON_STYLE  # Apply the specific back button style
        ).pack(pady=10, anchor="w", padx=10)

    def open_home_page(self):
        self.clear_frame()
        label = customtkinter.CTkLabel(
            self.scroll_frame.viewPort,
            text="Welcome to Priya Dairies",
            font=("Helvetica", 20),
            text_color="white"
        )
        label.pack(pady=20)

        self.create_styled_button(self.scroll_frame.viewPort, "Customer", self.open_customer_page).pack(pady=10)
        self.create_styled_button(self.scroll_frame.viewPort, "Supplier", self.open_supplier_page).pack(pady=10)

    def create_styled_button(self, parent, text, command):
        """Creates a modern, styled button using CustomTkinter."""
        button = customtkinter.CTkButton(
            parent,
            text=text,
            command=command,
            **GENERAL_BUTTON_STYLE  # Apply the general button style
        )
        return button


    # Specific function calls for supplier and customer login
    def open_supplier_page(self):
        open_login_page(
            self=self,
            role="Supplier",
            table_name="Supplier",
            dashboard_callback=lambda: open_supplier_dashboard(self),
            signup_callback=lambda: open_signup_details_supplier(self)
        )
    
    def open_customer_page(self):
        open_login_page(
            self=self,
            role="Customer",
            table_name="Customer",
            dashboard_callback=lambda: open_customer_dashboard(self),
            signup_callback=lambda: open_signup_details_customer(self)
        )

    def logout_supplier(self):
        """Log out the supplier and redirect to the login page."""
        session = Session()
        session.logout()
        self.open_supplier_page()

    def logout_customer(self):
        """Log out the customer and redirect to the login page."""
        session = Session()
        session.logout()
        self.open_customer_page()         

# Create the main application window
root = customtkinter.CTk()

# Create an instance of the DairyApp class
app = DairyApp(root)

# Run the application
root.mainloop()
