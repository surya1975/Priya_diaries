import hashlib
from tkinter import messagebox
import customtkinter
from session import Session  
from style import ENTRY_FIELD_STYLE
    
def open_login_page(self, role, table_name, dashboard_callback, signup_callback):
        """Generic login function for Supplier and Customer."""
        self.clear_frame()
        self.add_back_button(self.open_home_page)

        role_label = role.capitalize()
        label = customtkinter.CTkLabel(self.scroll_frame.viewPort, text=f"{role_label} Login", font=("Helvetica", 18), text_color="white")
        label.pack(pady=20)

        # Email entry
        username_label = customtkinter.CTkLabel(self.scroll_frame.viewPort, text="Email:", text_color="white")
        username_label.pack(pady=5)
        username_entry = customtkinter.CTkEntry(
            self.scroll_frame.viewPort,
            placeholder_text="Enter Email",
            **ENTRY_FIELD_STYLE  # Apply the global entry field style
        )
        username_entry.pack(pady=5)

        # Password entry
        password_label = customtkinter.CTkLabel(self.scroll_frame.viewPort, text="Password:", text_color="white")
        password_label.pack(pady=5)
        password_entry = customtkinter.CTkEntry(
            self.scroll_frame.viewPort,
            placeholder_text="Enter Password",
            show="*",
            **ENTRY_FIELD_STYLE  # Apply the global entry field style
        )
        password_entry.pack(pady=5)

        # Force UI update
        self.root.update_idletasks()

        # Login action
        def login_action():
            def hash_password(password):
                """Hash the password using SHA-256."""
                return hashlib.sha256(password.encode()).hexdigest()

            entered_username = username_entry.get()
            entered_password = password_entry.get()
            hashed_password = hash_password(entered_password)

            user = self.fetch_query(
                f"SELECT * FROM {table_name} WHERE email=%s AND password=%s",
                (entered_username, hashed_password)
            )
            if user:
                # Store the logged-in user's details in the session (singleton)
                session = Session()  # Get the session instance
                session.login({
                    "user_id": user[0],  # First column is the user ID (customer_id or supplier_id)
                    "name": user[1],     # Second column is the user's name
                    "email": user[5],    # Third column is the email
                    "user_type": role_label  # Store the user type
                })
                dashboard_callback()  # Navigate to the dashboard
            else:
                messagebox.showerror("Login", "Invalid credentials")

        # Signup action
        def signup_action():
            signup_callback()

        # Buttons
        self.create_styled_button(self.scroll_frame.viewPort, "Login", login_action).pack(pady=10)
        label = customtkinter.CTkLabel(self.scroll_frame.viewPort, text=f"Are you new {role_label}?", font=("Helvetica", 18), text_color="white")
        label.pack(pady=10)
        self.create_styled_button(self.scroll_frame.viewPort, "Signup", signup_action).pack(pady=10)