import customtkinter
from session import Session
from tkinter import messagebox
from cart import view_cart

def view_product_details(self, product_id, back_callback):
    """Display detailed information about a specific product."""
    # Clear the current frame
    self.clear_frame()

    # Get logged-in user data from the session singleton
    session = Session()
    user_data = session.get_user_data()
    user_id = user_data.get("user_id")  # Retrieve user ID from session

    # Navbar
    navbar = customtkinter.CTkFrame(self.scroll_frame.viewPort, height=50, fg_color="#333333", corner_radius=0)
    navbar.pack(side="top", fill="x", pady=2)

    # Add Back Button in navbar 
    customtkinter.CTkButton(
        navbar,
        text="Back",
        fg_color="#B22222",
        hover_color="#8B0000",
        width=120,
        height=30,
        command=lambda: back_callback(self) # This function handles rendering the "Add Store" page
    ).pack(side="left", padx=10, pady=10)

    # Add View Cart Button
    customtkinter.CTkButton(
        navbar,
        text="View Cart",
        fg_color="#4A90E2",
        hover_color="#256DAE",
        width=120,
        height=30,
        command=lambda: view_cart(self, user_id, back_callback) # This function handles rendering the "Add Store" page
    ).pack(side="right", padx=10, pady=10)

    # Fetch product details from the database
    try:
        product = self.fetch_query(
            """
            SELECT 
                Product.name AS product_name,
                Product.description,
                Product.price,
                Store.name AS store_name,
                Store.city,
                Store.street,
                Store.store_id
            FROM 
                Product
            JOIN 
                Store ON Product.store_id = Store.store_id
            WHERE 
                Product.product_id = %s
            """,
            (product_id,)
        )
    except Exception as e:
        print(f"Database error: {e}")
        customtkinter.CTkLabel(
            self.scroll_frame.viewPort,
            text="An error occurred while retrieving product details.",
            font=("Helvetica", 14),
            text_color="red"
        ).pack(pady=10)
        return

    # Display product details
    customtkinter.CTkLabel(
        self.scroll_frame.viewPort,
        text=f"Product Details: {product[0]}",
        font=("Helvetica", 18, "bold")
    ).pack(pady=10)

    details = {
        "Name": product[0],
        "Description": product[1],
        "Price": f"₹{product[2]:.2f}",
        "Store Name": product[3],
        "Store City": product[4],
        "Store Street": product[5]
    }

    for key, value in details.items():
        customtkinter.CTkLabel(
            self.scroll_frame.viewPort,
            text=f"{key}: {value}",
            font=("Helvetica", 14),
            anchor="w"
        ).pack(pady=5, padx=10)

    # Add "Add to Cart" button
    customtkinter.CTkButton(
        self.scroll_frame.viewPort,
        text="Add to Cart",
        command=lambda: add_to_cart(self, product_id, product[6]),  # Define the callback
        fg_color="#32CD32",
        hover_color="#2E8B57",
        text_color="white",
        corner_radius=8,
        width=35,
        height=36,
    ).pack(pady=50, padx=10)


def add_to_cart(self, product_id, store_id):
    """Add a product to the user's cart using session storage."""
    try:
        # Get logged-in user data from the session singleton
        session = Session()
        user_data = session.get_user_data()

        # If no user is logged in, redirect to login page
        if not user_data:
            # Redirect to login page
            self.open_customer_page()
            return

        user_id = user_data.get("user_id")  # Retrieve user ID from session

        # Initialize the cart for this user if it doesn't exist
        if not hasattr(self, "session_carts"):
            self.session_carts = {}  # Dictionary to store carts for each user

        if user_id not in self.session_carts:
            self.session_carts[user_id] = {"store_id": None, "products": {}}  # New cart structure

        # Retrieve the cart for the current user
        user_cart = self.session_carts[user_id]

        # Check if the cart already has a store_id
        if user_cart["store_id"] is None:
            # Set the store_id if this is the first product added to the cart
            user_cart["store_id"] = store_id
        elif user_cart["store_id"] != store_id:
            # Prevent adding products from different stores
            messagebox.showerror(
                "Error",
                "You can only add products from one store at a time. Please clear your cart to add products from a different store."
            )
            return

        # Add product to the cart
        if product_id in user_cart["products"]:
            # Increment quantity if product already in cart
            user_cart["products"][product_id] += 1
        else:
            # Add product with quantity 1
            user_cart["products"][product_id] = 1

        # Provide feedback to the user
        customtkinter.CTkLabel(
            self.scroll_frame.viewPort,
            text="Product added to cart successfully!",
            font=("Helvetica", 14),
            text_color="green"
        ).pack(pady=10)

        print(f"Current cart for user {user_id}: {user_cart}")  # Debugging output
    except Exception as e:
        print(f"Error: {e}")
        customtkinter.CTkLabel(
            self.scroll_frame.viewPort,
            text="An error occurred while adding the product to the cart.",
            font=("Helvetica", 14),
            text_color="red"
        ).pack(pady=10)
