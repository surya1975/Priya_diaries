class Session:
    """A singleton class for managing the user session."""
    _instance = None
    user_data = None

    def __new__(cls):
        if cls._instance is None:
            cls._instance = super(Session, cls).__new__(cls)
        return cls._instance

    def login(self, user_data):
        """Login and store user data."""
        self.user_data = user_data

    def logout(self):
        """Logout and clear user data."""
        self.user_data = None

    def get_user_data(self):
        """Return the current user data."""
        return self.user_data
