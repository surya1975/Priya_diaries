import customtkinter
from tkinter import messagebox
from datetime import datetime
from style import ENTRY_FIELD_STYLE


def checkout(self, user_id, back_callback):
    """
    Display the checkout page for the user to enter delivery details,
    select payment method, and place the order.
    """
    # Clear the current frame
    self.clear_frame()
    self.add_back_button(lambda: back_callback(self, user_id, back_callback))

    # Retrieve cart for the user
    session_cart = self.session_carts.get(user_id)
    # Retrieve the store_id from the session cart
    store_id = session_cart.get("store_id")

    # Title
    customtkinter.CTkLabel(
        self.scroll_frame.viewPort,
        text="Checkout",
        font=("Helvetica", 22, "bold"),
        text_color="white"
    ).pack(pady=10)

    # User Details
    customtkinter.CTkLabel(
        self.scroll_frame.viewPort,
        text="Enter Your Details:",
        font=("Arial", 14, "bold"),
        text_color="white"
    ).pack(anchor="w", padx=20, pady=5)

    user_details_frame = customtkinter.CTkFrame(self.scroll_frame.viewPort)
    user_details_frame.pack(pady=5, padx=20, fill="x")

    labels = ["First Name", "Last Name", "Email", "Phone"]
    user_entries = {}

    for i, label in enumerate(labels):
        customtkinter.CTkLabel(
            user_details_frame,
            text=f"{label}:",
            font=("Arial", 12),
            anchor="w"
        ).grid(row=i, column=0, padx=20, pady=5, sticky="w")
        entry = customtkinter.CTkEntry(
            user_details_frame,
            placeholder_text=f"Enter your {label.lower()}",
            **ENTRY_FIELD_STYLE
        )
        entry.grid(row=i, column=1, padx=10, pady=5, sticky="w")
        user_entries[label.lower()] = entry

    # Delivery Address
    customtkinter.CTkLabel(
        self.scroll_frame.viewPort,
        text="Delivery Address:",
        font=("Arial", 14, "bold"),
        text_color="white"
    ).pack(anchor="w", padx=20, pady=5)

    address_frame = customtkinter.CTkFrame(self.scroll_frame.viewPort)
    address_frame.pack(pady=5, padx=20, fill="x")

    address_fields = [
        "Apartment No",
        "Street",
        "City",
        "ZIP Code"
    ]
    address_entries = {}

    for i, label in enumerate(address_fields):
        customtkinter.CTkLabel(
            address_frame,
            text=f"{label}:",
            font=("Arial", 12),
            anchor="w"
        ).grid(row=i, column=0, padx=10, pady=5, sticky="w")
        entry = customtkinter.CTkEntry(
            address_frame,
            placeholder_text=f"Enter your {label.lower()}",
            **ENTRY_FIELD_STYLE
        )
        entry.grid(row=i, column=1, padx=10, pady=5, sticky="w")
        address_entries[label.lower()] = entry

    # Payment Method
    customtkinter.CTkLabel(
        self.scroll_frame.viewPort,
        text="Payment Method:",
        font=("Arial", 14, "bold"),
        text_color="white"
    ).pack(anchor="w", padx=20, pady=10)

    payment_var = customtkinter.StringVar(value="Card")

    credit_debit=customtkinter.CTkRadioButton(
        self.scroll_frame.viewPort,
        text="Credit/Debit Card",
        variable=payment_var,
        text_color="white",
        value="Card"
    )
    credit_debit.pack(anchor="w", padx=40)

    cash_on_delivery=customtkinter.CTkRadioButton(
        self.scroll_frame.viewPort,
        text="Cash on Delivery",
        variable=payment_var,
        text_color="white",
        value="COD"
    )
    cash_on_delivery.pack(anchor="w", padx=40)

    # Credit/Debit Card Fields
    card_frame = customtkinter.CTkFrame(self.scroll_frame.viewPort)
    card_frame.pack(fill="x", padx=40, pady=10)

    card_fields = {}
    card_labels = ["Card Number", "Expiry Date (MM/YY)", "CVV"]
    for i, label in enumerate(card_labels):
        customtkinter.CTkLabel(
            card_frame,
            text=f"{label}:",
            font=("Arial", 12),
            anchor="w"
        ).grid(row=i, column=0, padx=10, pady=5, sticky="w")
        entry = customtkinter.CTkEntry(
            card_frame,
            placeholder_text=f"Enter {label.lower()}",
            **ENTRY_FIELD_STYLE
        )
        entry.grid(row=i, column=1, padx=10, pady=5, sticky="w")
        card_fields[label.lower().replace(" ", "_")] = entry

    # Toggle card fields based on payment method
    def toggle_card_fields(*args):
        if payment_var.get() == "Card":
            # Ensure card_frame appears right after the Payment Method section
            card_frame.pack_forget()  # First hide the frame
            card_frame.pack(fill="x", padx=40, pady=10, after=credit_debit)  # Repack after the payment options
        else:
            card_frame.pack_forget()  # Hide it when not needed

    payment_var.trace_add("write", toggle_card_fields)

    # Place Order Button
    def place_order():
        print(user_entries)
        # Collect user details
        first_name = user_entries["first name"].get().strip()
        last_name = user_entries["last name"].get().strip()
        email = user_entries["email"].get().strip()
        phone = user_entries["phone"].get().strip()
        apartment_no = address_entries["apartment no"].get().strip()
        street = address_entries["street"].get().strip()
        city = address_entries["city"].get().strip()
        zip_code = address_entries["zip code"].get().strip()
        payment_method = payment_var.get()

        # Validation
        if not first_name or not last_name or not email or not phone or not apartment_no or not street or not city or not zip_code:
            messagebox.showerror("Error", "All fields except card details are required!")
            return

        if payment_method == "Card":
            card_number = card_fields["card_number"].get().strip()
            expiry_date = card_fields["expiry_date_(mm/yy)"].get().strip()
            cvv = card_fields["cvv"].get().strip()

            if not card_number or not expiry_date or not cvv:
                messagebox.showerror("Error", "Please fill in all card details wtih some data!")
                return

        # Insert order into database
        query = """
            INSERT INTO `Customer_Order` (
                first_name, last_name, email, phone, customer_id, store_id, apartment_no, street, city, zip, delivery_status, date, order_time
            ) VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)
        """
        params = (
            first_name,
            last_name,
            email,
            phone,
            user_id,
            store_id,
            apartment_no,
            street,
            city,
            zip_code,
            "Processing",
            datetime.now().date(),
            datetime.now()
        )
        try:
            order_number = self.order_execute(query, params)
            # Insert order items into Order_Item table
            cart = self.session_carts[user_id]
            for product_id, quantity in cart["products"].items():
                order_item_query = """
                    INSERT INTO `Order_Item` (order_number, product_id, quantity) 
                    VALUES (%s, %s, %s)
                """
                order_item_params = (order_number, product_id, quantity)
                self.execute_query(order_item_query, order_item_params)
            messagebox.showinfo("Success", f"Order placed successfully. Order Number: {order_number}")

            # Clear the cart after order placement
            self.session_carts[user_id] = {}

            # Redirect to the order confirmation page
            show_order_confirmation(self, order_number)
        except Exception as e:
            messagebox.showerror("Error", f"Failed to place order: {e}")

    # Add "Place Order" button
    customtkinter.CTkButton(
        self.scroll_frame.viewPort,
        text="Place Order",
        command=place_order,
        fg_color="#32CD32",
        hover_color="#2E8B57",
        text_color="white",
        corner_radius=8,
        width=60,
        height=42
    ).pack(pady=20, padx=20)

def show_order_confirmation(self, order_number):
    """Display the order confirmation page with all order details."""
    self.clear_frame()  # Clear the current content
    from customer_dash import open_customer_dashboard
    self.add_back_button(lambda: open_customer_dashboard(self))  # Add back button

    # Fetch order details from the database
    try:
        result = self.fetch_query(
            """
            SELECT 
                order_number,
                customer_id,
                Store.name AS store_name,
                apartment_no,
                Customer_Order.street,
                Customer_Order.city,
                Customer_Order.zip,
                delivery_status,
                order_time
            FROM 
                Customer_Order
            JOIN 
                Store ON Customer_Order.store_id = Store.store_id
            WHERE 
                order_number = %s
            """,
            (order_number,)
        )
    except Exception as e:
        print(f"Database error: {e}")
        customtkinter.CTkLabel(
            self.scroll_frame.viewPort,
            text="An error occurred while retrieving your order details.",
            font=("Helvetica", 14),
            text_color="red"
        ).pack(pady=10)
        return

    # Check if result exists
    if not result:
        customtkinter.CTkLabel(
            self.scroll_frame.viewPort,
            text="Order not found. Please try again later.",
            font=("Helvetica", 14),
            text_color="red"
        ).pack(pady=20)
        return
    try:
        items_result = self.fetch_all_query(
            """
            SELECT 
                Order_Item.product_id,
                Order_Item.quantity,
                Product.price
            FROM 
                Order_Item
            JOIN 
                Product ON Order_Item.product_id = Product.product_id
            WHERE 
                Order_Item.order_number = %s
            """,
            (order_number,)
        )
        print(items_result)
        
        total_price = sum(quantity * float(price) for _, quantity, price in items_result)
        result = list(result)
        result.insert(2, f"₹{total_price:.2f}")  # Insert total price in the 3rd position
        
    except Exception as e:
        print(f"Error fetching order items or calculating total price: {e}")

    # Add a title for the confirmation page
    customtkinter.CTkLabel(
        self.scroll_frame.viewPort,
        text="Order Confirmation",
        font=("Helvetica", 18, "bold"),
        text_color="white"
    ).pack(pady=10)

    # Define labels for the details with "Total Price" inserted after "Customer ID"
    labels = [
        "Order Number:",
        "Customer ID:",
        "Total Price:",
        "Store Name:",
        "Apartment No:",
        "Street:",
        "City:",
        "Zip Code:",
        "Delivery Status:",
        "Order Time:"
    ]
    # Loop through the result and display each detail in separate rows
    for idx, label in enumerate(labels):
        row_frame = customtkinter.CTkFrame(self.scroll_frame.viewPort)
        row_frame.pack(pady=5, padx=10, fill="x")

        # Add the label (with a fixed width)
        customtkinter.CTkLabel(
            row_frame,
            text=label,
            font=("Arial", 14, "bold"),
            anchor="w",
            width=50  # Fixed width for the label
        ).grid(row=0, column=0, padx=5, pady=5, sticky="w")

        value_to_display = str(result[idx])  # Convert the result to string

        # Add the corresponding value (with the same fixed width)
        customtkinter.CTkLabel(
            row_frame,
            text=value_to_display,
            font=("Arial", 14),
            anchor="w",
            width=50  # Same fixed width for the value
        ).grid(row=0, column=1, padx=5, pady=5, sticky="w")

        # Ensure the columns have a consistent width across all rows
        row_frame.grid_columnconfigure(0, weight=1, uniform="equal")
        row_frame.grid_columnconfigure(1, weight=1, uniform="equal")

    # Add a final confirmation message
    customtkinter.CTkLabel(
        self.scroll_frame.viewPort,
        text="Thank you for your order! We will process it shortly.",
        font=("Helvetica", 20),
        text_color="green"
    ).pack(pady=20)
