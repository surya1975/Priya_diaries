import customtkinter
from tkinter import messagebox
import mysql.connector
from session import Session
from style import ENTRY_FIELD_STYLE


def add_product_content(self, store_id, back_callback):
    """Render the Add Product content."""
    self.clear_frame()
    self.add_back_button(lambda: back_callback(self))

    label = customtkinter.CTkLabel(
        self.scroll_frame.viewPort,
        text="Add Product Details",
        font=("Helvetica", 18)
    )
    label.pack(pady=20)

    def create_field(frame, text, is_multiline=False):
        """Create a label and entry field."""
        customtkinter.CTkLabel(frame, text=text).pack(pady=5)
        if is_multiline:
            custom_style = ENTRY_FIELD_STYLE.copy()  # Create a copy to avoid altering the global style
            custom_style.update({"height": 120})
            entry = customtkinter.CTkEntry(
                frame, 
                placeholder_text=f"Enter {text}",
                **custom_style
                )
        else:
            entry = customtkinter.CTkEntry(
                frame,
                placeholder_text=f"Enter {text}",
                **ENTRY_FIELD_STYLE
            )
        entry.pack(pady=5)
        return entry

    # Fields for the product information
    fields = {
        "Product Name": create_field(self.scroll_frame.viewPort, "Product Name:"),
        "Description": create_field(self.scroll_frame.viewPort, "Description:", is_multiline=True),
        "Price": create_field(self.scroll_frame.viewPort, "Price (₹):")
    }
    print(fields)
    def validate_inputs(values):
        """Validate input fields."""
        errors = []
        if not values["Product Name"]:
            errors.append("Product Name is required.")
        if not values["Price"].replace('.', '', 1).isdigit():
            errors.append("Price must be a valid number.")
        if errors:
            messagebox.showerror("Validation Error", "\n".join(errors))
        return not errors

    def add_product_action(self, dashboard_callback):
        session = Session()
        user_data = session.get_user_data()

        """Handle the add product action."""
        # Collect the values from the fields
        field_values = {key: field.get().strip() for key, field in fields.items()}

        # Validate the inputs
        if not validate_inputs(field_values):
            return

        try:
            # Insert the new product into the database
            self.execute_query(
                """
                INSERT INTO Product (store_id, name, description, price) 
                VALUES (%s, %s, %s, %s)
                """,
                (
                    store_id,
                    field_values["Product Name"],
                    field_values["Description"],
                    float(field_values["Price"])  # Ensure price is a float
                )
            )
            messagebox.showinfo("Success", "Product added successfully!")
            dashboard_callback(self)  # Navigate back to the previous page (store dashboard)
        except mysql.connector.IntegrityError as e:
            print(f"Database error: {e}")
            messagebox.showerror("Error", "Could not add product due to database constraints.")
        except Exception as e:
            print(f"Unexpected error: {e}")
            messagebox.showerror("Error", "An error occurred while adding the product.")

    # Add Product button
    self.create_styled_button(self.scroll_frame.viewPort, "Add Product", lambda: add_product_action(self, back_callback)).pack(pady=20)
