from tkinter import messagebox
import customtkinter
from checkout import checkout

def view_cart(self, user_id, back_callback):
    # Clear the current frame
    self.clear_frame()
    self.add_back_button(lambda: back_callback(self))
    
    """View the contents of the cart for the logged-in user."""
    # Get the cart for the user from session_carts
    user_cart = self.session_carts.get(user_id, {})
    
    if not 'products' in user_cart:
        messagebox.showinfo("Cart", "Your cart is empty.")
        return
    else:
        products = user_cart.get("products", {})  # Retrieve the products dictionary

    # Display product details
    customtkinter.CTkLabel(
        self.scroll_frame.viewPort,
        text=f"Cart",
        font=("Helvetica", 22, "bold"),
        text_color="white"
    ).pack(pady=10)
    
    # Create headers for the cart view
    headers = ["Product Name", "Quantity", "Price", "Total"]
    column_widths = [12, 5, 8, 8]

    header_frame = customtkinter.CTkFrame(self.scroll_frame.viewPort)
    header_frame.pack(pady=5, padx=10, fill="x")

    for col, header in enumerate(headers):
        customtkinter.CTkLabel(
            header_frame,
            text=header,
            font=("Arial", 14, "bold"),
            anchor="w",
            width=column_widths[col] * 10
        ).grid(row=0, column=col, padx=5, pady=5, sticky="w")

    cart_price = 0
    # Display each product in the cart
    for row, (product_id, quantity) in enumerate(products.items(), start=1):
        # Fetch product details from the database or a product dictionary
        product = self.fetch_query(
            "SELECT name, price FROM Product WHERE product_id=%s",
            (product_id,)
        )
        if not product:
            continue  # Skip if product details are not found

        product_name, price = product[0], product[1]
        total_price = price * quantity
        cart_price += total_price

        # Create a row for the product
        row_frame = customtkinter.CTkFrame(self.scroll_frame.viewPort)
        row_frame.pack(pady=2, padx=10, fill="x")

        # Add product details to the row
        product_data = [product_name, quantity, f"₹{price:.2f}", f"₹{total_price:.2f}"]
        for col, value in enumerate(product_data):
            customtkinter.CTkLabel(
                row_frame,
                text=value,
                anchor="w",
                width=column_widths[col] * 10
            ).grid(row=0, column=col, padx=5, pady=2, sticky="w")

        # Add buttons for editing the cart (optional)
        customtkinter.CTkButton(
            row_frame,
            text="Remove",
            command=lambda p_id=product_id: remove_from_cart(self, user_id, p_id)
        ).grid(row=0, column=len(product_data), padx=5, pady=2)
     
     # Add the total price at the right side of the cart
    total_price_label = customtkinter.CTkLabel(
        self.scroll_frame.viewPort,
        text=f"Total: ₹{cart_price:.2f}",
        font=("Helvetica", 16, "bold"),
        text_color="white"
    )
    total_price_label.pack(pady=20, anchor="e", padx=20)  # Align the label to the right side
    
     # Add "Checkout" button
    customtkinter.CTkButton(
        self.scroll_frame.viewPort,
        text="Proceed to Checkout",
        command=lambda: checkout(self, user_id, view_cart),  # Define the callback
        fg_color="#32CD32",
        hover_color="#2E8B57",
        text_color="white",
        corner_radius=8,
        width=42,
        height=38,
    ).pack(pady=70, padx=20)    

def remove_from_cart(self, user_id, product_id):
    """Remove a product from the user's cart."""
    user_cart = self.session_carts.get(user_id, {})  
    # Check if the user has a cart and if the 'products' key exists
    if 'products' in user_cart:
        # Check if the product_id exists in the cart
        if product_id in user_cart['products']:
            # Remove the product from the cart
            del user_cart['products'][product_id]
            messagebox.showinfo("Cart", "Product removed from the cart! Go back and view the cart again to see changes.")
        else:
            messagebox.showwarning("Cart", "Product not found in the cart!")
    else:
        messagebox.showwarning("Cart", "No products in the cart!")

