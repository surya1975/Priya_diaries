import mysql.connector
from mysql.connector import errorcode

# Database configuration
DB_CONFIG = {
    'user': 'fatue2024bis698g3',
    'password': 'warm',
    'host': '141.209.241.91',
    'database': 'fatue2024bis698g3s',
}

# SQL commands to create tables
CREATE_TABLES_SQL = [
    """
    CREATE TABLE IF NOT EXISTS Supplier (
        supplier_id INT AUTO_INCREMENT PRIMARY KEY,
        first_name VARCHAR(255),
        last_name VARCHAR(255),
        phone BIGINT,
        email VARCHAR(255),
        password VARCHAR(255),
        street VARCHAR(255),
        city VARCHAR(255),
        state VARCHAR(255),
        zip_code INT
    );
    """,
    """
    CREATE TABLE IF NOT EXISTS Store (
        store_id INT AUTO_INCREMENT PRIMARY KEY,
        supplier_id INT, 
        name VARCHAR(255),
        street VARCHAR(255),
        city VARCHAR(255),
        state VARCHAR(255),
        zip_code INT,
        phone BIGINT,
        FOREIGN KEY (supplier_id) REFERENCES Supplier(supplier_id)
    );
    """,
    """
    CREATE TABLE IF NOT EXISTS Product (
        product_id INT AUTO_INCREMENT PRIMARY KEY,
        name VARCHAR(255),
        description TEXT,
        price DECIMAL(10, 2),
        store_id int,
        FOREIGN KEY (store_id) REFERENCES Store(store_id)
    );
    """,
    """
    CREATE TABLE IF NOT EXISTS Shipment (
        shipment_id INT AUTO_INCREMENT PRIMARY KEY,
        store_id INT,
        supplier_id INT,
        delivery_date DATE,
        FOREIGN KEY (store_id) REFERENCES Store(store_id),
        FOREIGN KEY (supplier_id) REFERENCES Supplier(supplier_id)
    );
    """,
    """
    CREATE TABLE IF NOT EXISTS Delivery_Driver (
        delivery_driver_id INT AUTO_INCREMENT PRIMARY KEY,
        store_id INT,
        first_name VARCHAR(255),
        last_name VARCHAR(255),
        FOREIGN KEY (store_id) REFERENCES Store(store_id)
    );
    """,
    """
    CREATE TABLE IF NOT EXISTS Customer (
        customer_id INT AUTO_INCREMENT PRIMARY KEY,
        first_name VARCHAR(255),
        last_name VARCHAR(255),
        phone BIGINT,
        email VARCHAR(255),
        password VARCHAR(255),
        street VARCHAR(255),
        city VARCHAR(255),
        state VARCHAR(255),
        zip_code INT
    );
    """,
    """
    CREATE TABLE IF NOT EXISTS Shipment_Product (
        shipment_prod_id INT AUTO_INCREMENT PRIMARY KEY,
        shipment_id INT,
        product_id INT,
        quantity INT,
        FOREIGN KEY (shipment_id) REFERENCES Shipment(shipment_id),
        FOREIGN KEY (product_id) REFERENCES Product(product_id)
    );
    """,
    """
    CREATE TABLE IF NOT EXISTS Store_Product (
        store_prod_id INT AUTO_INCREMENT PRIMARY KEY,
        store_id INT,
        product_id INT,
        quantity INT,
        FOREIGN KEY (product_id) REFERENCES Product(product_id),
        FOREIGN KEY (store_id) REFERENCES Store(store_id)
    );
    """,
    """
    CREATE TABLE IF NOT EXISTS `Customer_Order` (
        order_number INT AUTO_INCREMENT PRIMARY KEY,
        customer_id INT NOT NULL,
        first_name VARCHAR(255) NOT NULL,
        last_name VARCHAR(255) NOT NULL,
        email VARCHAR(255) NOT NULL,
        phone VARCHAR(20) NOT NULL,
        store_id INT NOT NULL,
        delivery_driver_id INT NULL,
        apartment_no VARCHAR(255),
        street VARCHAR(255),
        city VARCHAR(255),
        zip VARCHAR(20),
        delivery_status VARCHAR(255) DEFAULT 'Processing',
        date DATE NOT NULL,
        order_time DATETIME NOT NULL,
        FOREIGN KEY (delivery_driver_id) REFERENCES Delivery_Driver(delivery_driver_id),
        FOREIGN KEY (store_id) REFERENCES Store(store_id),
        FOREIGN KEY (customer_id) REFERENCES Customer(customer_id)
    );
    """,
    """
    CREATE TABLE IF NOT EXISTS Order_Item (
        order_item_id INT AUTO_INCREMENT PRIMARY KEY,
        order_number INT,
        product_id INT,
        quantity INT,
        FOREIGN KEY (order_number) REFERENCES `Customer_Order`(order_number),
        FOREIGN KEY (product_id) REFERENCES Product(product_id)
    );
    """
]

def initialize_database():
    """Initializes the MySQL database and creates tables if not already created."""
    try:
        # Connect to the MySQL server
        conn = mysql.connector.connect(**DB_CONFIG)
        cursor = conn.cursor()

        # Create tables
        for sql in CREATE_TABLES_SQL:
            cursor.execute(sql)

        conn.commit()
        print("Database and tables initialized successfully.")

    except mysql.connector.Error as err:
        if err.errno == errorcode.ER_ACCESS_DENIED_ERROR:
            print("Error: Invalid username or password")
        elif err.errno == errorcode.ER_BAD_DB_ERROR:
            print("Error: Database does not exist. Please create the database first.")
        else:
            print(f"Error: {err}")
    finally:
        if conn.is_connected():
            cursor.close()
            conn.close()


