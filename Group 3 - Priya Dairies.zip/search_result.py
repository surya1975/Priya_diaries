import customtkinter
from product import view_product_details, add_to_cart
def show_search_results(self, search_query, back_callback):
    """Display search results based on the query."""

    self.clear_frame()  # Clear the current content
    self.add_back_button(lambda: back_callback(self))

    # Add a title for the search results
    customtkinter.CTkLabel(
        self.scroll_frame.viewPort,
        text=f"Search Results for '{search_query}'",
        font=("Helvetica", 18),
        text_color="white"
    ).pack(pady=10)

    # Fetch matching products from the database
    try:
        results = self.fetch_all_query(
            """
            SELECT 
                product_id,
                Product.name AS product_name, 
                Store.name AS store_name, 
                Store.city,
                Product.price,
                Store.store_id
            FROM 
                Product
            JOIN 
                Store ON Product.store_id = Store.store_id
            WHERE 
                Product.name LIKE %s OR Store.name LIKE %s
            """,
            (f"%{search_query}%", f"%{search_query}%")
        )
    except Exception as e:
        print(f"Database error: {e}")
        customtkinter.CTkLabel(
            self.scroll_frame.viewPort,
            text="An error occurred while retrieving search results.",
            font=("Helvetica", 14),
            text_color="red"
        ).pack(pady=10)
        return

    # If no results are found
    if not results:
        customtkinter.CTkLabel(
            self.scroll_frame.viewPort,
            text="No matching products found.",
            font=("Helvetica", 14),
            text_color="gray"
        ).pack(pady=20)
        return

   # Define column widths for consistent alignment (match the number of headers)
    column_widths = [100, 100, 90, 80, 90, 90]  # Adjust widths as needed

    # Add headers to the top of the scrollable frame
    header_frame = customtkinter.CTkFrame(self.scroll_frame.viewPort)
    header_frame.pack(pady=5, padx=10, fill="x")

    # Define header labels
    headers = ["Product Name", "Store Name", "City", "Price", "Actions", "Actions"]  # Include both buttons as headers
    for col, header in enumerate(headers):
        customtkinter.CTkLabel(
            header_frame,
            text=header,
            font=("Arial", 14, "bold"),
            anchor="w",
            width=column_widths[col]
        ).grid(row=0, column=col, padx=5, pady=5, sticky="w")

    # Display each matching product
    for row, product in enumerate(results, start=1):  # Start at row 1 (row 0 is header)
        row_frame = customtkinter.CTkFrame(self.scroll_frame.viewPort)
        row_frame.pack(pady=2, padx=10, fill="x")

        # Product details for each row
        product_data = [
            str(product[1]),  # Product Name
            str(product[2]),  # Store Name
            str(product[3]),  # City
            f"₹{product[4]:.2f}"  # Format price 
        ]
        for col, value in enumerate(product_data):
            customtkinter.CTkLabel(
                row_frame,
                text=value if len(value) <= 20 else value[:17] + "...",  # Truncate if >20 characters
                anchor="w",
                width=column_widths[col],  # Fixed column width
                wraplength=column_widths[col] - 10  # Enable wrapping within the column width
            ).grid(row=0, column=col, padx=5, pady=2, sticky="w")

        # Add "View Product" button
        customtkinter.CTkButton(
            row_frame,
            text="View Product",
            command=lambda product_id=product[0]: view_product_details(self, product_id, back_callback),  # Define the callback
            fg_color="#1E90FF",
            hover_color="#4682B4",
            text_color="white",
            corner_radius=8,
            width=column_widths[len(product_data)],  # Match column width for "Actions"
            height=30,
        ).grid(row=0, column=len(product_data), padx=5, pady=2, sticky="w")

        # Add "Add to Cart" button
        customtkinter.CTkButton(
            row_frame,
            text="Add to Cart",
            command=lambda product_id=product[0], store_id=product[5]: add_to_cart(self, product_id, store_id),  # Define the callback
            fg_color="#32CD32",
            hover_color="#2E8B57",
            text_color="white",
            corner_radius=8,
            width=column_widths[len(product_data) + 1],  # Match column width for "Actions"
            height=30,
        ).grid(row=0, column=len(product_data) + 1, padx=5, pady=2, sticky="w")



def store_select_results(self, store_id, back_callback):
    """Display search results based on the query."""

    self.clear_frame()  # Clear the current content
    self.add_back_button(lambda: back_callback(self))

    # Fetch matching products from the database
    try:
        results = self.fetch_all_query(
            """
            SELECT 
                product_id,
                Product.name AS product_name, 
                Store.name AS store_name, 
                Store.city,
                Product.price
            FROM 
                Product
            JOIN 
                Store ON Product.store_id = Store.store_id
            WHERE 
                Store.store_id = %s 
            """,
            (store_id,) 
        )
    except Exception as e:
        print(f"Database error: {e}")
        customtkinter.CTkLabel(
            self.scroll_frame.viewPort,
            text="An error occurred while retrieving search results.",
            font=("Helvetica", 14),
            text_color="red"
        ).pack(pady=10)
        return
    print(results)
    # Add a title for the search results
    if results:
        customtkinter.CTkLabel(
            self.scroll_frame.viewPort,
            text=f"Product Results for '{results[0][2]}'",
            font=("Helvetica", 18),
            text_color="white"
        ).pack(pady=10)

    # If no results are found
    if not results:
        customtkinter.CTkLabel(
            self.scroll_frame.viewPort,
            text="No products found for this order.",
            font=("Helvetica", 18),
            text_color="gray"
        ).pack(pady=20)
        return

    # Define column widths for consistent alignment
    column_widths = [100, 100, 90, 80, 90, 90]  # Adjust widths as needed

    # Add headers to the top of the scrollable frame
    header_frame = customtkinter.CTkFrame(self.scroll_frame.viewPort)
    header_frame.pack(pady=5, padx=10, fill="x")

    # Define header labels
    headers = ["Product Name", "Store Name", "City", "Price", "Actions", "Actions"]
    for col, header in enumerate(headers):
        customtkinter.CTkLabel(
            header_frame,
            text=header,
            font=("Arial", 14, "bold"),
            anchor="w",
            width=column_widths[col] 
        ).grid(row=0, column=col, padx=5, pady=5, sticky="w")

    # Display each matching product
    for row, product in enumerate(results, start=1):  # Start at row 1 (row 0 is header)
        row_frame = customtkinter.CTkFrame(self.scroll_frame.viewPort)
        row_frame.pack(pady=2, padx=10, fill="x")

        # Product details for each row
        product_data = [
            str(product[1]),  # Product Name
            str(product[2]),  # Store Name
            str(product[3]),  # City
            f"₹{product[4]:.2f}"  # Format price
        ]
        for col, value in enumerate(product_data):
            customtkinter.CTkLabel(
                row_frame,
                text=value if len(value) <= 20 else value[:17] + "...",  # Truncate if >20 characters
                anchor="w",
                width=column_widths[col],  # Fixed column width
                wraplength=column_widths[col] - 10  # Enable wrapping within the column width
            ).grid(row=0, column=col, padx=5, pady=2, sticky="w")

        # Add "View Product" button
        customtkinter.CTkButton(
            row_frame,
            text="View Product",
            command=lambda product_id=product[0]: view_product_details(self, product_id, back_callback),  # Define the callback
            fg_color="#1E90FF",
            hover_color="#4682B4",
            text_color="white",
            corner_radius=8,
            width=25,
            height=30,
        ).grid(row=0, column=len(product_data), padx=5, pady=2, sticky="w")

        # Add "Add to Cart" button
        customtkinter.CTkButton(
            row_frame,
            text="Add to Cart",
            command=lambda product_id=product[0]: add_to_cart(self, product_id, store_id),  # Define the callback
            fg_color="#32CD32",
            hover_color="#2E8B57",
            text_color="white",
            corner_radius=8,
            width=25,
            height=30,
        ).grid(row=0, column=len(product_data) + 1, padx=5, pady=2, sticky="w")
