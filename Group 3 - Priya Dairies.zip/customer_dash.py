from tkinter import *
import customtkinter
from session import Session
from tkinter import messagebox
from style import ENTRY_FIELD_STYLE
from search_result import show_search_results, store_select_results
from cart import view_cart
from orders import display_customer_orders

def fetch_all_stores(self):
    """Fetch all stores added by the given supplier."""
    try:
        return self.fetch_all_query(
            """
            SELECT store_id, name, street, city, state, zip_code, phone 
            FROM Store
            ORDER BY store_id
            """
        )
    except Exception as e:
        print(f"Error fetching stores for supplier: {e}")
        return []
    

def open_customer_dashboard(self):
    """Render the supplier dashboard."""
    # Clear the scroll_frame to remove any previous widgets
    self.clear_frame()

    # Get logged-in user data from the session singleton
    session = Session()
    user_data = session.get_user_data()

    # If no user is logged in, redirect to login page
    if not user_data:
        #messagebox.showerror("Error", "You must be logged in first!")
        self.open_customer_page()
        return
    
    # Extract customer_id from user data
    customer_id = user_data.get("user_id")

    # Navbar
    navbar = customtkinter.CTkFrame(self.scroll_frame.viewPort, height=50, fg_color="#333333", corner_radius=0)
    navbar.pack(side="top", fill="x", pady=2)

    # Left side: Logged in as and Logout button
    left_frame = customtkinter.CTkFrame(navbar, fg_color="#333333", corner_radius=0)
    left_frame.pack(side="left", padx=10)

    # Customer Name Label (on the left)
    customtkinter.CTkLabel(
        left_frame,
        text=f"Logged in as: {user_data['name']}",
        text_color="white",
        font=("Helvetica", 14)
    ).pack(side="left", padx=10)

    # Logout Button (on the left, next to the customer name)
    customtkinter.CTkButton(
        left_frame,
        text="Logout",
        fg_color="#B22222",
        hover_color="#8B0000",
        width=80,
        height=30,
        command=self.logout_customer  # Handles logging out
    ).pack(side="left", padx=10)

    # Right side: Order History and View Cart buttons
    right_frame = customtkinter.CTkFrame(navbar, fg_color="#333333", corner_radius=0)
    right_frame.pack(side="right", padx=10)

    # Order History Button (on the right, next to View Cart)
    customtkinter.CTkButton(
        right_frame,
        text="Order History",
        fg_color="#4A90E2",
        hover_color="#256DAE",
        width=120,
        height=30,
        command=lambda: display_customer_orders(self, customer_id, open_customer_dashboard) # This function handles rendering the "Order History" page
    ).pack(side="left", padx=10, pady=10)

    # View Cart Button (on the far right)
    customtkinter.CTkButton(
        right_frame,
        text="View Cart",
        fg_color="#4A90E2",
        hover_color="#256DAE",
        width=120,
        height=30,
        command=lambda: view_cart(self, customer_id, open_customer_dashboard) # This function handles rendering the "View Cart" page
    ).pack(side="right", padx=10, pady=10)


    # Main Content Area
    Search_label = customtkinter.CTkLabel(
        self.scroll_frame.viewPort,
        text="Search Product Across Stores",
        font=("Helvetica", 20),
        text_color="white"
    )
    Search_label.pack(pady=20)

    def add_product_search(self):
        """Add product search functionality to the customer dashboard."""

        # Create a frame for the search bar
        search_frame = customtkinter.CTkFrame(
            self.scroll_frame.viewPort,
            fg_color="transparent"
            )
        search_frame.pack(pady=10, padx=10, fill="x")

        # Add a search entry field
        search_entry = customtkinter.CTkEntry(
            search_frame,
            placeholder_text="Search for a product...",
            **ENTRY_FIELD_STYLE
        )
        search_entry.pack(side="left", padx=10, fill="x", expand=True)

        search_button_style = {
            'height': 40,
            'width': 180,
            'font': ("Helvetica", 16),
            'text_color': "white",
            'corner_radius': 10,
            'fg_color': "#4A90E2",  # Blue button
            'hover_color': "#256DAE"
        }
        # Add a search button
        customtkinter.CTkButton(
            search_frame,
            text="Search",
            **search_button_style,
            command=lambda: handle_product_search(search_entry.get())  # Pass the search text to the handler
        ).pack(side="left", padx=10)

    def handle_product_search(search_text):
        """Handle the product search action."""
        if not search_text.strip():
            messagebox.showwarning("Warning", "Please enter a product name to search.")
            return

        # Navigate to the product search results page
        show_search_results(self, search_text, open_customer_dashboard)


    add_product_search(self)    
    Store_label = customtkinter.CTkLabel(
        self.scroll_frame.viewPort,
        text="Select Store to View It's Products",
        font=("Helvetica", 20),
        text_color="white"
    )
    Store_label.pack(pady=20)

    # Fetch stores added by the logged-in supplier
    stores = fetch_all_stores(self)

    if not stores:
        customtkinter.CTkLabel(
            self.scroll_frame.viewPort,
            text="No stores found.",
            font=("Helvetica", 14),
            text_color="white"
        ).pack(pady=10)
        return

     # Convert tuples to dictionaries for clarity
    stores = [
            {
                "store_id": row[0],
                "name": row[1],
                "street": row[2],
                "city": row[3],
                "state": row[4],
                "zip_code": row[5],
                "phone": row[6],
            }
            for row in stores
    ]

    # Display store data
    # Define column widths (adjust as per your expected content size)
    column_widths = [120, 150, 90, 100, 100]  # Corresponding to headers

    # Add headers to the top of the scrollable frame
    header_frame = customtkinter.CTkFrame(self.scroll_frame.viewPort)
    header_frame.pack(pady=5, padx=10, fill="x")

    # Define header labels
    headers = ["Store Name", "Street", "City", "Phone", "Actions"]
    for col, header in enumerate(headers):
        customtkinter.CTkLabel(
            header_frame,
            text=header,
            font=("Arial", 14, "bold"),
            anchor="w",  # Align text to the left
            width=column_widths[col] 
        ).grid(row=0, column=col, padx=5, pady=5, sticky="w")  # Use grid for consistent layout

    # Create a row frame for store data
    for row, store in enumerate(stores, start=1):  # Start at row 1 (row 0 is header)
        # Create a single frame for each row
        row_frame = customtkinter.CTkFrame(self.scroll_frame.viewPort)
        row_frame.pack(pady=2, padx=10, fill="x")  # Match header padding and alignment

        # Add store details to the respective columns
        store_data = [
            str(store["name"]),   # Ensure the name is a string
            str(store["street"]), # Ensure the street is a string
            str(store["city"]),   # Ensure the city is a string
            str(store["phone"]),  # Ensure the phone number is a string
        ]

        for col, value in enumerate(store_data):
            # For longer text fields, enable wrapping and truncate if necessary
            customtkinter.CTkLabel(
                row_frame,
                text=value if len(value) <= 20 else value[:17] + "...",  # Truncate if >30 characters
                anchor="w",  # Align text to the left
                width=column_widths[col],
                wraplength=column_widths[col] - 10  # Enable text wrapping
            ).grid(row=0, column=col, padx=5, pady=2, sticky="w")  # Match grid layout

        # Add Product button in the last column
        customtkinter.CTkButton(
            row_frame,
            text="Select Store",
            fg_color="#FFA500",
            hover_color="#FF8C00",
            command=lambda store_id=store["store_id"]: store_select_results(self, store_id, open_customer_dashboard),
            width=column_widths[-1] 
        ).grid(row=0, column=len(store_data), padx=5, pady=2, sticky="w")  # Match grid layout
    