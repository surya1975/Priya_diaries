from style import ENTRY_FIELD_STYLE
import customtkinter
from tkinter import messagebox
import mysql.connector
from session import Session


def add_store_content(self, back_callback):
    """Render the Add Store content."""
    self.clear_frame()
    self.add_back_button(lambda: back_callback(self))

    label = customtkinter.CTkLabel(
        self.scroll_frame.viewPort,
        text="Add Store Details",
        font=("Helvetica", 18),
        text_color="white"
    )
    label.pack(pady=20)

    def create_field(frame, text):
        """Create a label and entry field."""
        customtkinter.CTkLabel(frame, text=text, text_color="white").pack(pady=5)
        entry = customtkinter.CTkEntry(
            frame,
            placeholder_text=f"Enter {text}",
            **ENTRY_FIELD_STYLE
        )
        entry.pack(pady=5)
        return entry

    # Fields for the store information
    fields = {
        "Store Name": create_field(self.scroll_frame.viewPort, "Store Name:"),
        "Street": create_field(self.scroll_frame.viewPort, "Street:"),
        "City": create_field(self.scroll_frame.viewPort, "City:"),
        "State": create_field(self.scroll_frame.viewPort, "State:"),
        "Zip Code": create_field(self.scroll_frame.viewPort, "Zip Code:"),
        "Phone": create_field(self.scroll_frame.viewPort, "Phone:")
    }

    def validate_inputs(values):
        """Validate input fields."""
        errors = []
        if not values["Store Name"]:
            errors.append("Store Name is required.")
        if not values["Phone"].isdigit():
            errors.append("Phone must contain only numbers.")
        if not values["Zip Code"].isdigit():
            errors.append("Zip Code must contain only numbers.")
        if errors:
            messagebox.showerror("Validation Error", "\n".join(errors))
        return not errors

    def add_store_action(self, dashboard_callback):
        session = Session()
        user_data = session.get_user_data()
        supplier_id = user_data.get("user_id")

        """Handle the add store action."""
        # Collect the values from the fields
        field_values = {key: field.get().strip() for key, field in fields.items()}

        # Validate the inputs
        if not validate_inputs(field_values):
            return

        try:
            # Insert the new store into the database
            self.execute_query(
                """
                INSERT INTO Store (supplier_id, name, street, city, state, zip_code, phone) 
                VALUES (%s, %s, %s, %s, %s, %s, %s)
                """,
                (
                    supplier_id,
                    field_values["Store Name"],
                    field_values["Street"],
                    field_values["City"],
                    field_values["State"],
                    field_values["Zip Code"],
                    field_values["Phone"]
                )
            )
            messagebox.showinfo("Success", "Store added successfully!")
            dashboard_callback(self)  # Navigate back to the dashboard
        except mysql.connector.IntegrityError as e:
            print(f"Database error: {e}")
            messagebox.showerror("Error", "Could not add store due to database constraints.")
        except Exception as e:
            print(f"Unexpected error: {e}")
            messagebox.showerror("Error", "An error occurred while adding the store.")

    # Add Store button
    self.create_styled_button(self.scroll_frame.viewPort, "Add Store", lambda: add_store_action(self, back_callback)).pack(pady=20)
