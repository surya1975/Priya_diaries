from tkinter import *
import customtkinter
from session import Session
from tkinter import messagebox
from add_store import add_store_content
from add_product import add_product_content

def fetch_all_stores(self, supplier_id):
    """Fetch all stores added by the given supplier."""
    try:
        return self.fetch_all_query(
            """
            SELECT store_id, name, street, city, state, zip_code, phone 
            FROM Store
            WHERE supplier_id = %s
            ORDER BY store_id
            """,
            (supplier_id,)  # Pass the supplier_id as a parameter
        )
    except Exception as e:
        print(f"Error fetching stores for supplier {supplier_id}: {e}")
        return []


def open_supplier_dashboard(self):
    """Render the supplier dashboard."""
    # Clear the scroll_frame to remove any previous widgets
    self.clear_frame()

    # Get logged-in user data from the session singleton
    session = Session()
    user_data = session.get_user_data()

    # If no user is logged in, redirect to login page
    if not user_data:
        #messagebox.showerror("Error", "You must be logged in first!")
        self.open_supplier_page()
        return
    
    # Extract supplier_id from user data
    supplier_id = user_data.get("user_id")

    # Navbar
    navbar = customtkinter.CTkFrame(self.scroll_frame.viewPort, height=50, fg_color="#333333", corner_radius=0)
    navbar.pack(side="top", fill="x", pady=2)

    # Add Store Button
    customtkinter.CTkButton(
        navbar,
        text="+ Add Store",
        fg_color="#4A90E2",
        hover_color="#256DAE",
        width=100,
        height=30,
        command=lambda: add_store_content(self, open_supplier_dashboard) # This function handles rendering the "Add Store" page
    ).pack(side="left", padx=10, pady=10)

    # Supplier Name Label
    customtkinter.CTkLabel(
        navbar,
        text=f"Logged in as: {user_data['name']}",
        text_color="white",
        font=("Helvetica", 14)
    ).pack(side="right", padx=10)

    # Logout Button
    customtkinter.CTkButton(
        navbar,
        text="Logout",
        fg_color="#B22222",
        hover_color="#8B0000",
        width=80,
        height=30,
        command=self.logout_supplier  # Handles logging out
    ).pack(side="right", padx=10, pady=10)

    # Main Content Area
    welcome_label = customtkinter.CTkLabel(
        self.scroll_frame.viewPort,
        text="Welcome to the Supplier Dashboard",
        font=("Helvetica", 20),
        text_color="white"
    )
    welcome_label.pack(pady=20)

     # Fetch stores added by the logged-in supplier
    stores = fetch_all_stores(self, supplier_id)

    if not stores:
        customtkinter.CTkLabel(
            self.scroll_frame.viewPort,
            text="No stores added yet.",
            font=("Helvetica", 14),
            text_color="white"
        ).pack(pady=10)
        return

     # Convert tuples to dictionaries for clarity
    stores = [
            {
                "store_id": row[0],
                "name": row[1],
                "street": row[2],
                "city": row[3],
                "state": row[4],
                "zip_code": row[5],
                "phone": row[6],
            }
            for row in stores
    ]

   # Define column widths in pixels (adjusted for 600px window size)
    column_widths = [120, 150, 90, 100, 100]  # Total = ~640px including padding, adjust if needed

    # Add headers to the top of the scrollable frame
    header_frame = customtkinter.CTkFrame(self.scroll_frame.viewPort)
    header_frame.pack(pady=5, padx=10, fill="x")

    # Define header labels
    headers = ["Store Name", "Street", "City", "Phone", "Actions"]
    for col, header in enumerate(headers):
        customtkinter.CTkLabel(
            header_frame,
            text=header,
            font=("Arial", 14, "bold"),
            anchor="w",  # Align text to the left
            width=column_widths[col]
        ).grid(row=0, column=col, padx=5, pady=5, sticky="w")  # Use grid for consistent layout

    # Create a row frame for store data
    for row, store in enumerate(stores, start=1):  # Start at row 1 (row 0 is header)
        # Create a single frame for each row
        row_frame = customtkinter.CTkFrame(self.scroll_frame.viewPort)
        row_frame.pack(pady=2, padx=10, fill="x")  # Match header padding and alignment

        # Add store details to the respective columns
        store_data = [
            str(store["name"]),   # Ensure the name is a string
            str(store["street"]), # Ensure the street is a string
            str(store["city"]),   # Ensure the city is a string
            str(store["phone"]),  # Ensure the phone number is a string
        ]

        for col, value in enumerate(store_data):
            # For longer text fields, enable wrapping and truncate if necessary
            customtkinter.CTkLabel(
                row_frame,
                text=value if len(value) <= 20 else value[:17] + "...",  # Truncate if >30 characters
                anchor="w",  # Align text to the left
                width=column_widths[col],
                wraplength=column_widths[col] - 10  # Enable text wrapping
            ).grid(row=0, column=col, padx=5, pady=2, sticky="w")  # Match grid layout


        # Add Product button in the last column
        customtkinter.CTkButton(
            row_frame,
            text="+ Add Product",
            fg_color="#FFA500",
            hover_color="#FF8C00",
            command=lambda store_id=store["store_id"]: add_product_content(self, store_id, open_supplier_dashboard),
            width=column_widths[-1]
        ).grid(row=0, column=len(store_data), padx=5, pady=2, sticky="w")  # Match grid layout

    

def validate_inputs(values):
    """Validate input fields."""
    errors = []
    if not values["Store Name"]:
        errors.append("Store Name is required.")
    if not values["Phone"].isdigit():
        errors.append("Phone must contain only numbers.")
    if not values["Zip Code"].isdigit():
        errors.append("Zip Code must contain only numbers.")
    if errors:
        messagebox.showerror("Validation Error", "\n".join(errors))
    return not errors

