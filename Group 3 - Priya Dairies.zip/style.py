# Global Entry Field Style (since all entry fields look the same)
ENTRY_FIELD_STYLE = {
    'height': 40,
    'width': 250,
    'font': ("Helvetica", 16),
    'border_width': 2,
    'border_color': "cyan",
    'corner_radius': 10,
    'fg_color': "lightgray",
    'text_color': "black",
    'placeholder_text_color': "gray"
}

# General Button Style (for Login/Signup buttons)
GENERAL_BUTTON_STYLE = {
    'height': 50,
    'width': 200,
    'font': ("Helvetica", 16),
    'text_color': "white",
    'corner_radius': 20,
    'fg_color': "#4A90E2",  # Blue button
    'hover_color': "#256DAE"
}

# Back Button Style (different style for the Back button)
BACK_BUTTON_STYLE = {
    'height': 40,
    'width': 120,
    'font': ("Helvetica", 14),
    'text_color': "white",
    'corner_radius': 10,
    'fg_color': "#B22222",  # Red back button
    'hover_color': "#8B0000"
}